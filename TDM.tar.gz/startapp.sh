#!/bin/sh
export HOME=/config
exec /usr/bin/python3 /usr/local/bin/tdmgr.py
